from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.support.select import Select
from time import sleep
from lib import SeleniumWrapper
from pytest import mark


# driver=WebDriver()
# driver.get("https://demowebshop.tricentis.com/")
headers="gender","fname","lname","email","password"

data=[
    ("male","hello","world","helloworld@company.com",'hello123'),
    ("female","hello123","world123","helloworld@company.com",'hel123'),

]



@mark.parametrize(headers,data)
def test_register(setup_tear_down,_config,request,gender,fname,lname,email,password):
    s=SeleniumWrapper(setup_tear_down,request.config.option.time)
    
    # s.click_element(("link text","Register"))
    # s.click_element(("id","gender-male"))
    # s.enter_text(("id","FirstName"),value="vishnu")
    # s.enter_text(("id","LastName"),value="menothil")
    # s.enter_text(("id","Email"),value=_config.email)
    # s.enter_text(("id","Password"),value=_config.password)
    # s.enter_text(("id","ConfirmPassword"),value="vm123456")
    # s.click_element(("id","register-button")) 
    #using parametrize
    s.click_element(("link text","Register"))
    if gender.upper()=="MALE":
        s.click_element(("id","gender-male"))
    elif gender.upper() == "FEMALE":
        s.click_element(("id","gender-female"))

    else:
        raise Exception("unknown gender")
    
    s.enter_text(("id","FirstName"),value=fname)
    s.enter_text(("id","LastName"),value=lname)
    s.enter_text(("id","Email"),value=email)
    s.enter_text(("id","Password"),value=password)
    s.enter_text(("id","ConfirmPassword"),value=password)
    s.click_element(("id","register-button")) 


