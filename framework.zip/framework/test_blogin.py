# from selenium.webdriver.chrome.webdriver import WebDriver
# from selenium.webdriver.support.select import Select
# from time import sleep
from lib import SeleniumWrapper
from pytest import mark

#mark -object of a class used to create parametrize using method in the class parametrize() 

# driver=WebDriver()
# driver.get("https://demowebshop.tricentis.com/")

headers="email","password"

data=[
    ("vishnumenothil@gmail.com","vishnu7902"),
    ("abcdefg@gmail.com","company123"),
    ("abcdefg@gmail.com","company123"),
    ]

@mark.parametrize(headers,data)
def test_login(setup_tear_down,_config,request,email,password):
    s=SeleniumWrapper(setup_tear_down,request.config.option.time)
    
    s.click_element(("link text","Log in"))
    # s.enter_text(("id","Email"),value=_config.email)
    s.enter_text(("id","Email"),value=email) #using that parameter taking value from the list 
    # s.enter_text(("id","Password"),value=_config.password)
    s.enter_text(("id","Password"),value=password)



headers12="email","password"
data12=[
    ("vishnumenothil@gmail","vishnu7902"),
    ("abcdefg@gmail.com","company123"),
    ("abcdefg@gmail.com","company123"),
      ]

@mark.parametrize(headers12,data12)
def test_login_negative(setup_tear_down,_config,request,email,password):
    s=SeleniumWrapper(setup_tear_down,request.config.option.time)

    s.click_element(("link text","Log in"))
    s.enter_text(("id","Email"),value=email)
    s.enter_text(("id","Password"),value=password)







































































































































































































































































